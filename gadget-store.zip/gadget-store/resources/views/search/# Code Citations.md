# Code Citations

## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session
```


## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session()->get('cart', []);
```


## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session()->get('cart', []);
    if
```


## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session()->get('cart', []);
    if (
```


## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session()->get('cart', []);
    if (isset($cart[$productId]))
```


## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session()->get('cart', []);
    if (isset($cart[$productId])) {
        $cart[$productI
```


## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session()->get('cart', []);
    if (isset($cart[$productId])) {
        $cart[$productId]['quantity'] += $quantity;
```


## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session()->get('cart', []);
    if (isset($cart[$productId])) {
        $cart[$productId]['quantity'] += $quantity;
    } else {
        $cart
```


## License: unknown
https://github.com/GiaosuHung/doan2/blob/3c3c8bc49b99a11dfb2672f0b2cb633ed35127be/app/Http/Controllers/CartController.php

```
session()->get('cart', []);
    if (isset($cart[$productId])) {
        $cart[$productId]['quantity'] += $quantity;
    } else {
        $cart[$productId] = [
```

