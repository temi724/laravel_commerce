<div class="max-w-7xl mx-auto px-4 space-y-6">
    <!-- Page Header -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Sales Management</h1>
                <p class="mt-1 text-sm text-gray-600">View and manage customer orders and sales data</p>
            </div>
        </div>
    </div>

    <!-- Header with Search and Filters -->
    <div class="bg-white rounded-lg shadow-sm p-6">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div class="flex flex-col sm:flex-row gap-4 flex-1">
                <!-- Search -->
                <div class="flex-1">
                    <input type="text" wire:model.live="search"
                           placeholder="Search by customer name, email, or order ID..."
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                </div>
            </div>
        </div>

        <!-- Filters Row -->
        <div class="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
            <!-- Order Status Filter -->
            <select wire:model.live="statusFilter"
                    class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="all">All Order Status</option>
                <option value="pending">Pending Orders</option>
                <option value="completed">Completed Orders</option>
            </select>

            <!-- Payment Status Filter -->
            <select wire:model.live="paymentFilter"
                    class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="all">All Payment Status</option>
                <option value="pending">Payment Pending</option>
                <option value="completed">Payment Completed</option>
                <option value="failed">Payment Failed</option>
                <option value="refunded">Refunded</option>
            </select>

            <!-- Order Type Filter -->
            <select wire:model.live="orderTypeFilter"
                    class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="all">All Order Types</option>
                <option value="pickup">Pickup Orders</option>
                <option value="delivery">Delivery Orders</option>
            </select>
        </div>
    </div>

    <!-- Flash Messages -->
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?php echo e(session('message')); ?></span>
            <button type="button" class="absolute top-0 right-0 p-3" onclick="this.parentElement.style.display='none'">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            <button type="button" class="absolute top-0 right-0 p-3" onclick="this.parentElement.style.display='none'">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Sales Table -->
    <div class="bg-white rounded-lg shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Order ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Customer</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Items</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Order Type</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Order Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Payment Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Total</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Completion Date</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Approved By</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Date</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider whitespace-nowrap">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr wire:key="sale-<?php echo e($sale->id); ?>" class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900">#<?php echo e($sale->order_id); ?></div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="space-y-1">
                                    <div class="text-sm font-medium text-gray-900"><?php echo e($sale->username); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo e($sale->emailaddress); ?></div>
                                    <div class="text-xs text-gray-400"><?php echo e($sale->phonenumber); ?></div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo e($sale->quantity); ?> items</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?php echo e($sale->order_type === 'delivery' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'); ?>">
                                    <?php echo e(ucfirst($sale->order_type)); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full <?php echo e($sale->order_status ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                    <?php echo e($sale->order_status ? 'Completed' : 'Pending'); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex px-2 py-1 text-xs font-medium rounded-full
                                    <?php if($sale->payment_status === 'completed'): ?> bg-green-100 text-green-800
                                    <?php elseif($sale->payment_status === 'pending'): ?> bg-yellow-100 text-yellow-800
                                    <?php elseif($sale->payment_status === 'failed'): ?> bg-red-100 text-red-800
                                    <?php else: ?> bg-gray-100 text-gray-800 <?php endif; ?>">
                                    <?php echo e(ucfirst($sale->payment_status)); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-semibold text-gray-900">₦<?php echo e(number_format($this->getOrderTotal($sale), 2)); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <!--[if BLOCK]><![endif]--><?php if($sale->completed_at): ?>
                                    <div class="text-sm text-gray-900"><?php echo e($sale->completed_at->format('M j, Y')); ?></div>
                                    <div class="text-xs text-gray-500"><?php echo e($sale->completed_at->format('g:i A')); ?></div>
                                <?php else: ?>
                                    <div class="text-sm text-gray-400">Not completed</div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <!--[if BLOCK]><![endif]--><?php if($sale->approved_by_admin): ?>
                                    <div class="text-sm text-gray-900"><?php echo e($sale->approved_by_admin); ?></div>
                                    <!--[if BLOCK]><![endif]--><?php if($sale->payment_approved_at): ?>
                                        <div class="text-xs text-gray-500"><?php echo e($sale->payment_approved_at->format('M j, g:i A')); ?></div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <?php else: ?>
                                    <div class="text-sm text-gray-400">Not approved</div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900"><?php echo e($sale->created_at->format('M j, Y')); ?></div>
                                <div class="text-xs text-gray-500"><?php echo e($sale->created_at->format('g:i A')); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex space-x-2">
                                    <button wire:click="toggleExpanded('<?php echo e($sale->id); ?>')"
                                            class="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        <svg class="w-4 h-4 mr-1 transition-transform duration-200 <?php echo e(in_array($sale->id, $this->expandedRows) ? 'rotate-180' : ''); ?>" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                                        </svg>
                                        <?php echo e(in_array($sale->id, $this->expandedRows) ? 'Hide' : 'View'); ?>

                                    </button>
                                    <!--[if BLOCK]><![endif]--><?php if(!$sale->order_status): ?>
                                        <!--[if BLOCK]><![endif]--><?php if($sale->payment_status === 'completed'): ?>
                                            <button wire:click="confirmOrderStatusUpdate('<?php echo e($sale->id); ?>')"
                                                    class="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                </svg>
                                                Complete
                                            </button>
                                        <?php else: ?>
                                            <button disabled
                                                    title="Payment must be completed first"
                                                    class="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-400 bg-gray-100 cursor-not-allowed opacity-50">
                                                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                </svg>
                                                Complete
                                            </button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    <!--[if BLOCK]><![endif]--><?php if($sale->payment_status === 'pending'): ?>
                                        <button wire:click="confirmPaymentStatusUpdate('<?php echo e($sale->id); ?>')"
                                                class="inline-flex items-center px-3 py-1 border border-transparent text-sm leading-4 font-medium rounded-md text-red-600 bg-red-100 hover:bg-red-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500">
                                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"></path>
                                            </svg>
                                            Mark Paid
                                        </button>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </td>
                        </tr>

                        <!-- Expandable Row -->
                        <!--[if BLOCK]><![endif]--><?php if(in_array($sale->id, $this->expandedRows)): ?>
                        <tr class="bg-gray-50">
                            <td colspan="11" class="px-6 py-4">
                                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                    <!-- Customer Information -->
                                    <div>
                                        <h4 class="text-lg font-medium text-gray-900 mb-4">Customer Information</h4>
                                        <div class="space-y-3">
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Name:</span>
                                                <span class="font-medium"><?php echo e($sale->username); ?></span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Email:</span>
                                                <span class="font-medium"><?php echo e($sale->emailaddress); ?></span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Phone:</span>
                                                <span class="font-medium"><?php echo e($sale->phonenumber); ?></span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Location:</span>
                                                <span class="font-medium"><?php echo e($sale->location ?? 'N/A'); ?></span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Order Information -->
                                    <div>
                                        <h4 class="text-lg font-medium text-gray-900 mb-4">Order Information</h4>
                                        <div class="space-y-3">
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Quantity:</span>
                                                <span class="font-medium"><?php echo e($sale->quantity); ?> items</span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Type:</span>
                                                <span class="font-medium"><?php echo e(ucfirst($sale->order_type)); ?></span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Status:</span>
                                                <span class="inline-flex px-2 py-1 text-xs rounded-full <?php echo e($sale->order_status ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                                    <?php echo e($sale->order_status ? 'Completed' : 'Pending'); ?>

                                                </span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Payment Status:</span>
                                                <span class="inline-flex px-2 py-1 text-xs rounded-full
                                                    <?php if($sale->payment_status === 'completed'): ?> bg-green-100 text-green-800
                                                    <?php elseif($sale->payment_status === 'pending'): ?> bg-yellow-100 text-yellow-800
                                                    <?php elseif($sale->payment_status === 'failed'): ?> bg-red-100 text-red-800
                                                    <?php else: ?> bg-gray-100 text-gray-800 <?php endif; ?>">
                                                    <?php echo e(ucfirst($sale->payment_status)); ?>

                                                </span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Total:</span>
                                                <span class="font-bold text-lg">₦<?php echo e(number_format($this->getOrderTotal($sale), 2)); ?></span>
                                            </div>
                                            <div class="flex justify-between">
                                                <span class="text-gray-600">Date:</span>
                                                <span class="font-medium"><?php echo e($sale->created_at->format('M j, Y g:i A')); ?></span>
                                            </div>
                                            <!--[if BLOCK]><![endif]--><?php if($sale->completed_at): ?>
                                                <div class="flex justify-between">
                                                    <span class="text-gray-600">Completed At:</span>
                                                    <span class="font-medium text-green-600"><?php echo e($sale->completed_at->format('M j, Y g:i A')); ?></span>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <!--[if BLOCK]><![endif]--><?php if($sale->approved_by_admin): ?>
                                                <div class="flex justify-between">
                                                    <span class="text-gray-600">Approved By:</span>
                                                    <span class="font-medium text-blue-600"><?php echo e($sale->approved_by_admin); ?></span>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <!--[if BLOCK]><![endif]--><?php if($sale->payment_approved_at): ?>
                                                <div class="flex justify-between">
                                                    <span class="text-gray-600">Payment Approved:</span>
                                                    <span class="font-medium text-green-600"><?php echo e($sale->payment_approved_at->format('M j, Y g:i A')); ?></span>
                                                </div>
                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                        </div>
                                    </div>
                                </div>

                                <!-- Products -->
                                <div class="mt-6">
                                    <h4 class="text-lg font-medium text-gray-900 mb-4">Products Ordered</h4>
                                    <div class="space-y-4">
                                        <!--[if BLOCK]><![endif]--><?php if($sale->order_details && is_array($sale->order_details)): ?>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sale->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="flex items-start justify-between p-4 bg-white rounded-lg border border-gray-200">
                                                    <div class="flex items-start space-x-4 flex-1">
                                                        <!--[if BLOCK]><![endif]--><?php if(isset($item['image']) && $item['image']): ?>
                                                            <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>" class="w-16 h-16 rounded-lg object-cover">
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        <div class="flex-1">
                                                            <h5 class="font-medium text-gray-900"><?php echo e($item['name'] ?? 'Unknown Product'); ?></h5>
                                                            <div class="mt-1 text-sm text-gray-600 space-y-1">
                                                                <!--[if BLOCK]><![endif]--><?php if(isset($item['selected_storage'])): ?>
                                                                    <div>Storage: <?php echo e($item['selected_storage']); ?></div>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <!--[if BLOCK]><![endif]--><?php if(isset($item['selected_color'])): ?>
                                                                    <div>Color: <?php echo e($item['selected_color']); ?></div>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                <div>Quantity: <?php echo e($item['quantity'] ?? 1); ?></div>
                                                                <div>Price: ₦<?php echo e(number_format($item['price'] ?? 0, 2)); ?></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="text-right">
                                                        <div class="font-bold text-lg">₦<?php echo e(number_format($item['subtotal'] ?? 0, 2)); ?></div>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            <div class="flex justify-between items-center p-4 bg-gray-50 rounded-lg border border-gray-200 mt-4">
                                                <span class="font-semibold text-gray-900">Order Total:</span>
                                                <span class="font-bold text-xl text-blue-600">₦<?php echo e(number_format($this->getOrderTotal($sale), 2)); ?></span>
                                            </div>
                                        <?php elseif($sale->product_ids && is_array($sale->product_ids)): ?>
                                            <!-- Fallback to product_ids if order_details is not available -->
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sale->product_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $product = \App\Models\Product::find($productId) ?? \App\Models\Deal::find($productId);
                                                ?>
                                                <!--[if BLOCK]><![endif]--><?php if($product): ?>
                                                    <div class="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200">
                                                        <!--[if BLOCK]><![endif]--><?php if($product->images_url && count($product->images_url) > 0): ?>
                                                            <img src="<?php echo e($product->images_url[0]); ?>" alt="<?php echo e($product->product_name); ?>" class="w-12 h-12 rounded-lg object-cover mr-3">
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        <span class="font-medium flex-1"><?php echo e($product->product_name ?? $product->name); ?></span>
                                                        <span class="font-bold">₦<?php echo e(number_format($product->price, 2)); ?></span>
                                                    </div>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <?php else: ?>
                                            <p class="text-gray-500">No products information available</p>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="11" class="px-6 py-12 text-center text-gray-500">
                                <div class="flex flex-col items-center">
                                    <svg class="w-12 h-12 text-gray-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                                    </svg>
                                    <h3 class="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
                                    <p class="text-gray-500">Orders will appear here once customers start making purchases.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <!--[if BLOCK]><![endif]--><?php if($sales->hasPages()): ?>
        <div class="bg-white rounded-lg shadow-sm border border-gray-200 px-6 py-4">
            <?php echo e($sales->links()); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!-- Compact Confirmation Modal -->
    <!--[if BLOCK]><![endif]--><?php if($showConfirmModal): ?>
        <div class="fixed inset-0   flex items-center justify-center z-50 p-4">
            <div class="bg-white rounded-lg shadow-xl w-full max-w-md">
                <div class="p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-2">Confirm Action</h3>
                    <p class="text-sm text-gray-600 mb-6"><?php echo e($confirmMessage); ?></p>

                    <div class="flex justify-end space-x-3">
                        <button wire:click="cancelConfirmation"
                                class="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 transition-colors">
                            Cancel
                        </button>
                        <button wire:click="executeConfirmedAction"
                                class="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors">
                            Confirm
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /Users/pro/Documents/GitHub/laravel_commerce/gadget-store/resources/views/livewire/admin/sales-manager.blade.php ENDPATH**/ ?>